const API_KEY =  "a3fda9b9d1d0aaee95df37313c16684e";
const BASE_URL = "https://api.themoviedb.org/3";
const IMAGE_URL = "https://image.tmdb.org/t/t/p/w500";

const campoPesquisa = document.getElementById("campoPesquisa");
const botaoPesquisa = document.getElementById("botaoPesquisa");
const filmesGrid = document.getElementById("filmesGrid");
const inicio = document.getElementById("inicio");
const filmes = document.getElementById("filmes");
const series = document.getElementById("series");

async function requisicaoURL(url) {
    try {
        filmesGrid.classList.add("fade-out");
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error("Erro na requisição: ");
        }
        const data = await response.json();
        seTimeout(() =>{
            rederizarMidia(data.results);
            filmesGrid.classList.remove("fade-out");
            filmesGrid.classList.add("fade-in");
            seTimeout(() =>{
                filmesGrid
            })
        })
        renderizarMidia(data.results);
    }catch (error) {
        console.error("Erro", error);
        filmesGrid.innerHTML = '<p>Erro ao carregar filmes</p>'; 
    }
}
function renderizarMidia(filmes){
    filmesGrid.innerHTML = "";
    if (!filmes || filmes.length === 0) {
        filmesGrid.innerHTML = '<p>Nenhum filme encontrado</p>';
        return;
    }
    filmes.forEach(filme => {
        const card = document.createElement("div");
        card.classList.add("card");
        const imagem = filme.poster_path
            ? `${IMAGE_URL}${filme.poster_path}`
            : "";
            if(filme.title) {  
            card.innerHTML = `
            <img src="${imagem}" alt="${filme.title}">
            <h3>${filme.title}</h3>
            <p>${filme.vote_average}
               ${filme.overview}
               ${filme.genre_ids}
               ${filme.release_date}
            </p>
        `;
     }else{
        card.innerHTML = `
            <img src="${imagem}" alt="${filme.name}">
            <h3>${filme.name}</h3>
            <p>${filme.vote_average}
               ${filme.overview}
               ${filme.genre_ids}
               ${filme.release_date}
            </p>
        `;
     }    
     card.addEventListener("click", () => {
        window.location.href = `pages/detalhe.html?id=${filme.id}&type=${filme.media_type}`;
     });
        filmesGrid.appendChild(card);
    })
}
function pesquisaGeral () {
    const informacao = campoPesquisa.value.trim();
    if (informacao === "") {
        carregarTendenciasGeral();
        return;
    }
    console.log("Pesquisando por:", informacao);
    const url = `${BASE_URL}/search/multi?api_key=${API_KEY}&language=pt-BR&query=${encodeURIComponent(informacao)}`;
    requisicaoURL(url);
    campoPesquisa.value = "";
}
    botaoPesquisa.addEventListener("click", pesquisaGeral);
    campoPesquisa.addEventListener("keydown", function (event) {
        if (event.key === "Enter") {
            pesquisaGeral();
        }
    }
    )
    document.addEventListener("DOMContentLoaded", carregarTendenciasGeral);
     inicio.addEventListener("click", carregarTendenciasGeral);
     filmes.addEventListener("click", buscarFilme);
     series.addEventListener("click", buscarSerie);

     function carregarTendenciasGeral() {
    const url = `${BASE_URL}/trending/movie/week?api_key=${API_KEY}&language=pt-BR`;
    requisicaoURL(url);
}
document.addEventListener("DOMContentLoaded", carregarTendenciasGeral);

function buscarFilme(){
    const url = `${BASE_URL}/trending/movie/week?api_key=${API_KEY}&language=pt-BR`;
    requisicaoURL(url);
}

function buscarSerie(){
    const url = `${BASE_URL}/trending/tv/week?api_key=${API_KEY}&language=pt-BR`;
    requisicaoURL(url);
}

botaoPesquisa.addEventListener("click", pesquisaGeral);
campoPesquisa.addEventListener("keydown", function (event) {
    if (event.key === "Enter") {
        pesquisaGeral();
    }
});

document.addEventListener("DOMContentLoaded", carregarTendenciasGeral);
inicio.addEventListener("click", carregarTendenciasGeral);
filmes.addEventListener("click", buscaFilme);
series.addEventListener("click", buscaSerie);

window.addEventListener("load", function (){
    const loader = document.getElementById("loader");
    if (loader) {
        loader.style.transition = "opacity 0.5s ease";
        loader.style.opacity = "0";
        this.setTimeout(() => {
            loader.style.display = "nome;"
        }, 500);
    }
});